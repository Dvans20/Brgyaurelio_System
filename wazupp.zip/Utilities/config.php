<?php 

require_once $linkExt."admin/Utilities/Database.php";

require_once $linkExt."admin/Models/WebSetting.php";

$web = WebSetting::get();


    




