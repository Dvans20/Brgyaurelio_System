<?php 
$conx = new mysqli("localhost", "root", "", "brgyaurelio");
$conx -> set_charset("utf8");
extract($_GET);
if (isset($updatedata)) {
   echo $sql = "UPDATE `$table` SET `$column`='$value' WHERE `$condition`='$identifier'";
    $query = $conx->query($sql);
}
 ?>