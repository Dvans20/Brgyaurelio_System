<!DOCTYPE html>
<html lang="en">
<head>
    
<?php 
    require_once 'templates/head.php';
?>
</head>
<body class="d-flex w-100">

    <?php 
        include_once 'Views/templates/sidebar.php';
    ?>

    <div class="container-fluid p-0 body_container">

        <?php include_once "Views/templates/header.php" ?>

        
        <div class="container w-100 pt-5 mt-5">
        
            <h3 class="text-center w-100 text-muted pt-5 mt-5 shake_in">
                Page Not Found
            </h3>
        </div>


    </div>


   

    


    <?php 
        include_once 'Views/templates/foot.php';
    ?>
</body>
</html>