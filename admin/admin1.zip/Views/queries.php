<?php 
echo "string";
 ?>