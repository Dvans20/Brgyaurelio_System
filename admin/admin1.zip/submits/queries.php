<?php
$con = new mysqli("localhost", "root", "", "brgyaurelio");

// Check for connection errors
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

$con->set_charset("utf8");

extract($_POST);
extract($_GET); // Fixed typo from "extrat" to "extract"

if (isset($new_program)) {
    // Prepared statement to prevent SQL injection
    $sql = "INSERT INTO `programs` (`program_name`, `program_desc`, `program_status`, `program_members`) 
            VALUES (?, ?, '0', '0')";
    
    // Prepare the statement
    $stmt = $con->prepare($sql);
    
    // Bind parameters to the statement
    $stmt->bind_param("ss", $program_title, $program_desc); // "ss" means two string parameters
    
    // Execute the statement
    if ($stmt->execute()) {
        echo "1"; // Successfully inserted
    } else {
        echo "0"; // Failed to insert
    }
    
    // Close the statement
    $stmt->close();
}

// Close the connection


if (isset($editProgramform)) {
    // Prepare the SQL query with placeholders
    $sql = "UPDATE `programs` 
            SET `program_name` = ?, `program_desc` = ?, `program_status` = ? 
            WHERE `program_id` = ?";
    
    // Prepare the statement
    $stmt = $con->prepare($sql);
    
    if ($stmt) {
        // Bind parameters to the prepared statement
        // "sssi" means: string, string, string, integer
        $stmt->bind_param("sssi", $program_title, $program_desc, $program_status, $program_id);
        
        // Execute the query
        if ($stmt->execute()) {
            echo "1"; // Success
        } else {
            echo "0"; // Failure
        }
        
        // Close the statement
        $stmt->close();
    } else {
        // Error in preparing the statement
        echo "Error preparing statement: " . $con->error;
    }
}



?>
