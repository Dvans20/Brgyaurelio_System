<?php 

require_once "../Utilities/Database.php";
require_once "../Models/RBBO.php";
require_once "../Models/WebSetting.php";
require_once "../Models/Log.php";
require_once "../Models/User.php";

require_once "../Models/Mailer.php";

class RBBOController {
    

    public static function saveRBBO($datas)
    {
        foreach ($datas as $k => $v) {
            $$k = $v;
        }

        $response = [
            'status' => 2,
            'msg' => "",
            'datas' => $datas
        ];

        $pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/';

        $year = date('Y');

        if (date('m') / 1 <= 6) {
            $qtr = 2;
        } else {
            $qtr = 4;
        }

        $emptyValidator = false;

        if ($existency != 1) {
            // new RBBO
            $emptyValidator = empty($purok) || empty($onwnersName) || empty($residenceAddress) || empty($businessName) || empty($category) || empty($type) || empty($contactNo) || empty($email) || empty($passKey);
        } else {
            $emptyValidator = empty($purok) || empty($onwnersName) || empty($residenceAddress) || empty($businessName) || empty($category) || empty($type) || empty($contactNo) || empty($email) || empty($passKey);
        }

        if ($emptyValidator) {
            $response['msg'] = "All fields are required.";
        } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $response['msg'] = "Inavlid Email.";
        } else if (RBBO::findByEmail($email, $year, $qtr) != null) {
            $response['msg'] = "Your email is already in use. Please use another email.";
        } else if (RBBO::findByContactNo($contactNo, $year, $qtr) != null) {
            $response['msg'] = "Your contact no. is already in use. Please use another contact no.";
        } else if (!preg_match($pattern, $passKey) && empty($busNo)) {
            $response['msg'] = "Pass key must contain a lowercase, uppercase, number, any special character and at least 8 characters.";
        } else {
            
            $rbbo = new RBBO();
            $rbbo->purok = $purok;
            $rbbo->onwnersName = $onwnersName;
            $rbbo->residenceAddress =$residenceAddress;
            $rbbo->businessName = $businessName;
            $rbbo->category = $category;
            $rbbo->type = $type;
            $rbbo->contactNo = $contactNo;
            $rbbo->email = $email;

            $rbbo->passKey = $passKey;

            if ($existency == 1) {
                $rbbo->busNo = $busNo;
            } else {
                $rbbo->busNo = 0;
            }
            
            $rbbo->year = $year;
            $rbbo->qtr = $qtr;
            $rbbo->status = 0;

            $rbbo->save();

            $response['status']  = 3;
            $response['msg'] = "<strong>Thank You</strong> <br> Your information is currently being processed. We appreciate your patience and will notify you shortly with an update.";
        }
 
        echo json_encode($response);
    }

    public static function getRBBOByKey($datas)
    {
        foreach ($datas as $k => $v) {
            $$k = $v;
        }

        $web = WebSetting::get();

        $response = [
            'status' => 2,
            'msg' => "",
            'rbbo' => $datas
        ];

        $year = date('Y');

        if (date('m') / 1 <= 6) {
            $qtr = 2;
        } else {
            $qtr = 4;
        }

        $rbbo = RBBO::findByKey($existingBONo, $existingPassKey);

        if ($rbbo == null) {
            $response['msg'] = "Incorrect Credentials.";
        } else if ($rbbo->year == $year && $rbbo->qtr == $qtr && $rbbo->status == 0) {
            $response['status'] = 5;
            $response['msg'] = "<strong>Thank You</strong> <br> Your information is currently being processed. We appreciate your patience and will notify you shortly with an update.";
        } else if ($rbbo->year == $year && $rbbo->qtr == $qtr && $rbbo->status == 1) {
            $response['status'] = 5;
            $response['msg'] = "Your information has already been verified and aproved. If you have any questions or need further assistance, please don't hesitate to reach out to us. <br> Thank you for your cooperation!";
        } else if ($rbbo->year == $year && $rbbo->qtr == $qtr && $rbbo->status == 2) {
            $response['status'] = 5;
            $response['msg'] = "Your information update/registration has been declined due to the following reasons.";
            $response['msg'] .= "<ul>";

            foreach (unserialize($rbbo->statusMsg) as $reason) {
                $response['msg'] .= "<li>". $reason ."</li>";
            }

            $response['msg'] .= "</ul>";


            $response['msg'] .= "<p>Please retry the registraion/update process or you may contact us ". $web->contactNo ." or email as ". $web->email .". You can also visit us at ". $web->address .".</p>";

            $response['msg'] .= "<p><b>Thank You And Mabuhay</b></p>";
        } else {
            $response['status'] = 3;
            $response['msg'] = "Welcome Back!";
            $response['rbbo'] = $rbbo;
        }

        echo json_encode($response);
    }

    public static function getRBBO($datas)
    {
        foreach ($datas as $k => $v) {
            $$k = $v;
        }

        $rbbos = RBBO::findAll($search, $purok, $year, $qtr, $category, $type, $status, $page, $limit);

        $count = RBBO::countAll($search, $purok, $year, $qtr, $category, $type, $status);

        $response = [
            'rbbos' => $rbbos,
            'totalPages' => ceil($count / $limit)
        ];

        echo json_encode($response);
    }

    public static function generateBusNo()
    {
        echo json_encode(RBBO::generateNo());
    }

    public static function approveRBBO($datas)
    {
        foreach ($datas as $k => $v) {
            $$k = $v;
        }

        $year = date('Y');

        if (date('m') / 1 <= 6) {
            $qtr = 2;
        } else {
            $qtr = 4;
        }

        $response = [
            'status' => 2,
            'msg' => "",
            'datas' => $datas
        ];


        $rbbo = RBBO::findById($id);

        $busNum = $busNo;

        if (empty($busNo)) {
            $response['msg'] = "Business No. is required.";
        } else if (!is_numeric($busNum)) {
            $response['msg'] = "invalid Business No.";
        } else if (RBBO::findByBusNo($busNo, 1, $year, $qtr) != null) {
            $response['msg'] = "Business No. Already Taken";
        } else {
            $rbbo->busNo = $busNo;

            $rbbo->status = 1;

            $rbbo->update();

             // Mail Here
             $mailer = new Mailer();
             $mailer->recipientAddress = $rbbo->email;
 
             $mailer->isHTML = true;
 
             $mailer->subject = "Your Business Registration/Update";
 
 
             $mailer->body = '<div style="max-width: 300px; width: 100%; display: block; margin: auto; border: 1px solid rgba(0,0,0,.3); border-radius: 30px; text-align: center;"><p><b>Your Business Registration/Update has been Approved.</b></p> <br> <p>Bus No. '.$rbbo->busNo.'</p> <br> <p>Thank You!!</p>';
 
             $mailer->send();
             // Mail Here
 
             // SMS HERE
             // SMS HERE

             Log::saveNewActivity("Approved", "Approved the business registration/update of " . $rbbo->onwnersName . ".");

            $response['status'] = 3;
            $response['msg'] = "RBBO registration/update Approved.";

        }

        echo json_encode($response);
    }

    public static function declineRBBO($datas)
    {
        foreach ($datas as $k => $v) {
            $$k = $v;
        }

        $web = WebSetting::get();

        $year = date('Y');

        if (date('m') / 1 <= 6) {
            $qtr = 2;
        } else {
            $qtr = 4;
        }

        $response = [
            'status' => 2,
            'msg' => "",
            'datas' => $datas
        ];

        if (empty($reasons) || empty($id)) {
            $response['msg'] = "Please select a reason for declining.";
        } else {
            $rbbo = RBBO::findById($id);
            $rbbo->status = 2;
            $rbbo->statusMsg = serialize(value: $reasons);

            $rbbo->update();

             // Mail Here
             $mailer = new Mailer();
             $mailer->recipientAddress = $rbbo->email;
 
             $mailer->isHTML = true;
 
             $mailer->subject = "Your Business Registration/Update";
 
 
             $mailer->body = "<p>Your Business Registration/Update has been declined due to the following reasons.</p>";

             $mailer->body .= "<ul>";
 
             foreach ($reasons as $reason) {
                 $mailer->body .= "<li>". $reason ."</li>";
             }
 
             $mailer->body .= "</ul>";
 
 
             $mailer->body .= "<p>Please retry the registraion/update process or you may contact us ". $web->contactNo ." or email as ". $web->email .". You can also visit us at ". $web->address .".</p>";
 
             $mailer->body .= "<p><b>Thank You And Mabuhay</b></p>";
 
             $mailer->send();
             // Mail Here
 
             // SMS HERE
             // SMS HERE

             Log::saveNewActivity("Declined", "Declined the business registration/update of " . $rbbo->onwnersName . ".");

            $response['status'] = 3;
            $response['msg'] = "RBBO registration/update Declined.";
        }


        echo json_encode($response);
    }

    public static function deleteRBBO($id)
    {

        $response = [
            'status' => 2,
            'msg' => ""
        ];

        $rbbo = RBBO::findById($id);

        $rbbo->delete();

        Log::saveNewActivity("Deleted", "Deleted the business registration/update of " . $rbbo->onwnersName . ".");


        $response['status'] = 3;
        $response['msg'] = "RBBO registration/update Deleted.";

        echo json_encode($response);
    }
}