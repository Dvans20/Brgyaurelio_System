<?php 



require_once "../Utilities/Database.php";
require_once "../Models/FAQ.php";

class FAQsController extends FAQ {

    
}