<?php 

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once '../../vendor/autoload.php';

// email
// brgyaurelio@gmail.com

// password
// brgyAurelio12_2

// pin 
// 1202


// xiad ahpf xnms tpbr


// sms recovery code code
// KVBB9KU9GRUZAZL8CWDFMRFB

class Mailer {

    public $isHTML = false;

    public $recipientAddress;

    public $subject;
    public $body;

    private $appEMail = "brgyaurelio@gmail.com";



    public function send()
    {
        $mail = new PHPMailer(true); // Create a new PHPMailer instance

        try {
            // Server settings
            $mail->isSMTP(); // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com'; // Specify main and backup SMTP servers
            $mail->SMTPAuth = true; // Enable SMTP authentication
            $mail->Username = $this->appEMail; // SMTP username
            $mail->Password = 'xiadahpfxnmstpbr'; // SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption
            $mail->Port = 587; // TCP port to connect to

            // Recipients
            $mail->setFrom($this->appEMail);
            $mail->addAddress($this->recipientAddress); // Add a recipient

            // Content
            $mail->isHTML($this->isHTML); // Set email format to HTML
            $mail->Subject = $this->subject;
            $mail->Body    = $this->body;
            $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

            $mail->send();
            // echo 'Email has been sent';
        } catch (Exception $e) {
            // echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }

    

}